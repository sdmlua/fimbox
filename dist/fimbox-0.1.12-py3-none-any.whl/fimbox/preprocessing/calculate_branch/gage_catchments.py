"""
Author: Supath Dhital
Date Updated: May 2026

Gage watershed delineation and outlet backpool mitigation.

Steps:
  1. stream_pixel_points      Vectorise stream pixel centroids to points GeoPackage.
  2. GageCatchments           Reverse-D8 label propagation from outlet points.
  3. OutletBackpoolMitigate   Detect and trim oversized outlet catchment (non-branch-zero only).

Inputs / outputs:
  demDerived_streamPixels_{id}.tif           --> flows_points_pixels_{id}.gpkg
  demDerived_reaches_split_points_{id}.gpkg  --> gw_catchments_reaches_{id}.tif
  flows_points_pixels_{id}.gpkg              --> gw_catchments_pixels_{id}.tif
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import geopandas as gpd
import numpy as np
import rasterio
import rasterio.features
import rasterio.sample
from numba import njit
from shapely import ops as shapely_ops
from shapely.geometry import Point

from ._d8 import downstream_index

log = logging.getLogger(__name__)


# Stream pixel centroids
def stream_pixel_points(
    stream_pixels: Path,
    out_gpkg: Path,
) -> Path:
    """
    Convert stream pixel raster to point GeoPackage with sequential IDs.

    Parameters
    ----------
    stream_pixels : demDerived_streamPixels_{id}.tif (value 1 = stream)
    out_gpkg      : flows_points_pixels_{id}.gpkg
    """
    stream_pixels = Path(stream_pixels)
    out_gpkg = Path(out_gpkg)

    with rasterio.open(str(stream_pixels)) as src:
        data = src.read(1)
        transform = src.transform
        crs = src.crs

    row_idxs, col_idxs = np.nonzero(data >= 1)
    xs = transform[2] + (col_idxs + 0.5) * transform[0]
    ys = transform[5] + (row_idxs + 0.5) * transform[4]

    ids = np.arange(1, len(row_idxs) + 1, dtype=np.int32)
    points = [Point(x, y) for x, y in zip(xs, ys)]

    gdf = gpd.GeoDataFrame({"id": ids, "geometry": points}, crs=crs)
    out_gpkg.parent.mkdir(parents=True, exist_ok=True)
    gdf.to_file(str(out_gpkg), driver="GPKG", index=False, engine="fiona")

    log.info("stream_pixel_points: %d points --> %s", len(gdf), out_gpkg.name)
    return out_gpkg


# gage watershed
@dataclass
class GageCatchments:
    """
    Delineate gage watersheds via iterative reverse-D8 label propagation.

    Each cell is labeled with the ID of the nearest downstream outlet point.
    Runs in multiple vectorised passes until convergence; typically converges
    in ≤500 passes for 10-m DEMs with 2-km reach segments.

    Parameters
    ----------
    flowdir        : flowdir_d8_burned_filled_{id}.tif (WBT D8 pointer)
    outlet_points  : GeoPackage with point geometries and integer 'id' column
    out_path       : output watershed raster
    max_iter       : safety cap on propagation iterations (default 5000)
    declutter      : solidify the raster before writing (default False). Fills
                     interior pits, removes the diagonal "checkerboard" along
                     divides, and reduces each HydroID to one connected piece, so
                     it polygonizes into clean, hole-free catchments the SRC step
                     can integrate. Reach catchments opt in; pixel catchments are
                     legitimately single-cell and leave it off.
    """

    flowdir: Path
    outlet_points: Path
    out_path: Path
    max_iter: int = 5000
    declutter: bool = False

    def __post_init__(self):
        for attr in ("flowdir", "outlet_points", "out_path"):
            setattr(self, attr, Path(getattr(self, attr)))

    def run(self) -> Path:
        with rasterio.open(str(self.flowdir)) as src:
            d8 = src.read(1)
            nodata_d8 = src.nodata
            profile = src.profile.copy()
            transform = src.transform
            crs = src.crs

        outlets_gdf = gpd.read_file(str(self.outlet_points), engine="fiona").to_crs(crs)

        outlet_rc_ids: list[tuple[int, int, int]] = []
        rows_n, cols_n = d8.shape
        for _, row_data in outlets_gdf.iterrows():
            pt = row_data.geometry
            col_f, row_f = ~transform * (pt.x, pt.y)
            r, c = int(row_f), int(col_f)
            if 0 <= r < rows_n and 0 <= c < cols_n:
                outlet_rc_ids.append((r, c, int(row_data["id"])))

        log.info(
            "GageCatchments: %d outlet points, propagating --> %s",
            len(outlet_rc_ids),
            self.out_path.name,
        )

        result = _gage_watershed(
            d8, outlet_rc_ids, nodata_d8=nodata_d8, max_iter=self.max_iter
        )

        # Solidify the reach raster so it polygonizes into clean, hole-free,
        # one-piece-per-HydroID catchments (the SRC step integrates these pixels
        # directly, so the raster must be sound). Order matters: declutter can
        # detach a cell into a new island, so connectivity enforcement runs last.
        if self.declutter:
            result = _fill_interior_holes(result)
            result = _declutter_boundaries(result)
            result = _enforce_connectivity(result)

        # int32 is supported by all GIS tools and HydroIDs using the fimid
        # prefix (4 digits + 4 seq = 8 digits) fit within it.
        profile.update(
            dtype="int32",
            nodata=0,
            compress="lzw",
            tiled=True,
            blockxsize=512,
            blockysize=512,
            BIGTIFF="YES",
        )
        self.out_path.parent.mkdir(parents=True, exist_ok=True)
        with rasterio.open(str(self.out_path), "w", **profile) as dst:
            dst.write(result.astype(np.int32), 1)

        log.info("GageCatchments: written --> %s", self.out_path.name)
        return self.out_path


def _fill_interior_holes(labels: np.ndarray) -> np.ndarray:
    """Fill unlabelled cells that are fully enclosed by catchments.

    Reverse-D8 propagation leaves a few cells unlabelled — D8 pits/sinks and
    short flow paths that terminate before reaching a seeded outlet. Inside a
    catchment these become 0-valued holes that vectorise into polygon holes.

    Each interior hole (a background component not touching the raster edge) is
    filled with its nearest labelled cell. The outside background is left at 0.
    """
    from scipy import ndimage

    out = labels.astype(np.int32).copy()
    background = out == 0
    if not background.any():
        return out

    # interior holes = background components that do not reach the raster edge.
    cross = np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]])
    comp, n = ndimage.label(background, structure=cross)
    edge_labels = set(
        np.unique(np.concatenate([comp[0, :], comp[-1, :], comp[:, 0], comp[:, -1]]))
    )
    edge_labels.discard(0)
    interior = np.isin(comp, [i for i in range(1, n + 1) if i not in edge_labels])
    if not interior.any():
        return out

    # nearest labelled cell for every background pixel, then apply to holes only.
    nearest = ndimage.distance_transform_edt(
        background, return_distances=False, return_indices=True
    )
    out[interior] = out[tuple(nearest)][interior]

    log.info("GageCatchments: filled %d interior hole cells", int(interior.sum()))
    return out


def _orthogonal_neighbours(lab: np.ndarray, flat_idx: np.ndarray) -> np.ndarray:
    """The 4 edge-neighbour labels at `flat_idx`, as (4, m); 0 off the grid.

    Order is south, north, east, west — the order the majority vote breaks ties in.
    """
    rows, cols = lab.shape
    flat = lab.ravel()
    r, c = flat_idx // cols, flat_idx % cols
    out = np.zeros((4, flat_idx.size), dtype=lab.dtype)
    for k, (dr, dc) in enumerate(((1, 0), (-1, 0), (0, 1), (0, -1))):
        rr, cc = r + dr, c + dc
        on_grid = (rr >= 0) & (rr < rows) & (cc >= 0) & (cc < cols)
        out[k, on_grid] = flat[rr[on_grid] * cols + cc[on_grid]]
    return out


def _declutter_boundaries(labels: np.ndarray, max_iter: int = 50) -> np.ndarray:
    """
    Remove artefacts along catchment boundaries.
    Reassign corner-only cells to the dominant 4-neighbour label until stable.

    Teeth are a handful of cells out of hundreds of millions, so the pass finds
    them first and votes only there — the whole-grid neighbour stack it used to
    build cost gigabytes of copying per iteration.
    """
    lab = labels.astype(np.int32).copy()
    background = lab == 0

    for iteration in range(max_iter):
        # A cell keeps its label if any edge-neighbour matches it. Off-grid
        # neighbours count as background, which only ever matters for background
        # cells — and those are excluded from teeth anyway.
        same_label_edge = np.zeros(lab.shape, dtype=bool)
        eq_vertical = lab[1:, :] == lab[:-1, :]
        same_label_edge[:-1, :] |= eq_vertical
        same_label_edge[1:, :] |= eq_vertical
        eq_horizontal = lab[:, 1:] == lab[:, :-1]
        same_label_edge[:, :-1] |= eq_horizontal
        same_label_edge[:, 1:] |= eq_horizontal

        # "teeth": labelled cells sharing no edge (only corners) with their own label.
        teeth = np.flatnonzero(~background.ravel() & ~same_label_edge.ravel())
        if teeth.size == 0:
            break

        # Majority vote over the 4 orthogonal neighbours, ignoring background.
        neighbours = _orthogonal_neighbours(lab, teeth)
        valid = neighbours > 0
        best_label = np.zeros(teeth.size, dtype=lab.dtype)
        best_count = np.zeros(teeth.size, dtype=np.int64)
        for k in range(4):
            candidate = neighbours[k]
            count = ((neighbours == candidate) & valid).sum(axis=0) * (candidate > 0)
            take = count > best_count
            best_count = np.where(take, count, best_count)
            best_label = np.where(take, candidate, best_label)

        apply = best_count > 0
        if not apply.any():
            break  # remaining teeth are fully isolated (no labelled edge neighbour).
        lab.flat[teeth[apply]] = best_label[apply]

    n_changed = int((lab != labels).sum())
    log.info(
        "GageCatchments: declutter relabelled %d boundary cells (%d passes)",
        n_changed,
        iteration + 1,
    )
    return lab


def _enforce_connectivity(labels: np.ndarray, max_iter: int = 8) -> np.ndarray:
    """Reduce every HydroID to a single 8-connected component.

    Off-channel seeds and declutter can strand small fragments of a HydroID
    inside a neighbour; filter_catchments later drops them, leaving gaps that
    corrupt the SRC area. For each HydroID the largest component is kept; every
    other fragment is reassigned to the majority label on its boundary ring.
    A fragment is 8-disconnected from its own id, so the ring is the enclosing
    catchment(s) — one solid piece per HydroID, no gaps, area conserved.

    Reassignments are repeated until stable: when two fragments border each
    other, one pass can leave a residue that the next pass mops up.
    """
    from scipy import ndimage

    lab = labels.astype(np.int32).copy()
    rows, cols = lab.shape
    structure_8 = np.ones((3, 3), dtype=int)

    n_merged = 0
    for _ in range(max_iter):
        bboxes = ndimage.find_objects(lab)
        merge_idx: list[np.ndarray] = []
        merge_val: list[np.ndarray] = []
        for hid in np.unique(lab[lab > 0]):
            sl = bboxes[hid - 1] if hid - 1 < len(bboxes) else None
            if sl is None:
                continue
            comp, n_comp = ndimage.label(lab[sl] == hid, structure=structure_8)
            if n_comp <= 1:
                continue
            largest = int(np.bincount(comp.ravel())[1:].argmax()) + 1

            # pad the bbox by one cell so the fragment's boundary ring is visible
            r0 = max(sl[0].start - 1, 0)
            r1 = min(sl[0].stop + 1, rows)
            c0 = max(sl[1].start - 1, 0)
            c1 = min(sl[1].stop + 1, cols)
            win = lab[r0:r1, c0:c1]
            comp_win = np.zeros(win.shape, dtype=np.int32)
            comp_win[
                sl[0].start - r0 : sl[0].stop - r0, sl[1].start - c0 : sl[1].stop - c0
            ] = comp

            for k in range(1, n_comp + 1):
                if k == largest:
                    continue
                fragment = comp_win == k
                ring = ndimage.binary_dilation(fragment, structure_8) & ~fragment
                ring_labels = win[ring]
                ring_labels = ring_labels[(ring_labels > 0) & (ring_labels != hid)]
                if ring_labels.size == 0:
                    continue  # fully isolated fragment (only borders nodata) — leave it
                values, counts = np.unique(ring_labels, return_counts=True)
                rr, cc = np.where(fragment)
                merge_idx.append((rr + r0) * cols + (cc + c0))
                merge_val.append(
                    np.full(rr.size, int(values[counts.argmax()]), dtype=np.int32)
                )

        if not merge_idx:
            break
        idx = np.concatenate(merge_idx)
        lab.flat[idx] = np.concatenate(merge_val)
        n_merged += idx.size

    log.info("GageCatchments: connectivity merged %d island cells", n_merged)
    return lab


@njit(cache=True)
def _label_downstream_paths(
    ds: np.ndarray, result: np.ndarray, state: np.ndarray
) -> None:
    """Give every cell the label of the first seed on its downstream path.

    Seeds arrive already marked done in ``state``, which is what stops the walk.
    Each path is walked twice — once to find the label, once to stamp it — and
    every cell is marked done on the way, so the whole grid costs O(n) rather
    than one traversal per cell.
    """
    n = ds.size
    for start in range(n):
        if state[start] == 2:
            continue

        j = start
        while state[j] == 0:
            state[j] = 1
            nxt = ds[j]
            if nxt == j:  # pit or off-grid: nothing downstream to inherit from
                result[j] = 0
                state[j] = 2
                break
            j = nxt

        # state 1 here means the walk came back on itself — a flow cycle, which
        # the label can't come out of, so the whole path stays unlabelled.
        label = result[j] if state[j] == 2 else 0

        j = start
        while state[j] != 2:
            result[j] = label
            state[j] = 2
            j = ds[j]


def _gage_watershed(
    d8: np.ndarray,
    outlet_rc_ids: list[tuple[int, int, int]],
    nodata_d8: Optional[float] = None,
    max_iter: int = 5000,  # kept for API compatibility, unused
) -> np.ndarray:
    """
    Algorithm: label propagation in topological downstream-->upstream order.
    Each cell inherits the label of its downstream neighbor, so its label is the
    first outlet found by walking downstream; cells whose path reaches no outlet
    stay 0.

    Runtime O(n): every cell is visited exactly once.
    """
    rows, cols = d8.shape
    n = rows * cols

    flat_d8 = d8 if nodata_d8 is None else np.where(d8 == int(nodata_d8), 0, d8)
    ds = downstream_index(flat_d8)

    result = np.zeros(n, dtype=np.int32)
    state = np.zeros(n, dtype=np.uint8)  # 0 unseen, 1 on the current path, 2 settled

    # Fix every outlet cell to its own id first. Seeds sit next to each other
    # along the channel, so they must all be pinned before propagation — else an
    # upstream seed gets overwritten by a downstream seed's label.
    for r, c, hid in outlet_rc_ids:
        idx = int(r) * cols + int(c)
        result[idx] = hid
        state[idx] = 2

    _label_downstream_paths(ds, result, state)

    log.debug(
        "gage_watershed: %d/%d cells labeled",
        int((result > 0).sum()),
        n,
    )
    return result.reshape(rows, cols)


# Outlet backpool mitigation
@dataclass
class OutletBackpoolMitigate:
    """
    Detect and trim oversized outlet catchment.

    Criteria (both must be met to trigger mitigation):
      1. At least one pixel catchment is an outlier (>1 std dev above mean size).
      2. The outlier catchment is at the network outlet (last segment NextDownID == -1).

    When triggered:
      - Trim the outlet reach to its penultimate vertex.
      - Update split_points to match the trimmed reach.
      - Mask the outlier catchment from both catchment rasters.

    Branch zero is always skipped (no 'levpa_id' in nwm streams).

    Parameters
    ----------
    branch_dir              : branch output directory
    catchment_pixels_path   : gw_catchments_pixels_{id}.tif
    catchment_reaches_path  : gw_catchments_reaches_{id}.tif
    split_flows_gpkg        : demDerived_reaches_split_{id}.gpkg
    split_points_gpkg       : demDerived_reaches_split_points_{id}.gpkg
    nwm_streams_gpkg        : nwm_subset_streams.gpkg (used to detect branch zero)
    dem_path                : dem_thalwegCond_{id}.tif (for slope recalculation)
    slope_min               : minimum slope floor (default 0.0001)
    """

    branch_dir: Path
    catchment_pixels_path: Path
    catchment_reaches_path: Path
    split_flows_gpkg: Path
    split_points_gpkg: Path
    nwm_streams_gpkg: Path
    dem_path: Path
    slope_min: float = 0.0001

    def __post_init__(self):
        for attr in (
            "branch_dir",
            "catchment_pixels_path",
            "catchment_reaches_path",
            "split_flows_gpkg",
            "split_points_gpkg",
            "nwm_streams_gpkg",
            "dem_path",
        ):
            setattr(self, attr, Path(getattr(self, attr)))

    def run(self) -> bool:
        """
        Run mitigation. Returns True if mitigation was applied, False otherwise.
        """
        # Skip for branch zero
        if self.nwm_streams_gpkg.exists():
            nwm = gpd.read_file(str(self.nwm_streams_gpkg), engine="fiona")
            if "levpa_id" not in nwm.columns:
                log.info("OutletBackpoolMitigate: branch zero — skipping")
                return False
        else:
            log.info("OutletBackpoolMitigate: nwm_streams not found — skipping")
            return False

        if not self.catchment_pixels_path.exists():
            log.warning("OutletBackpoolMitigate: catchment_pixels not found — skipping")
            return False

        split_flows = gpd.read_file(str(self.split_flows_gpkg), engine="fiona")
        split_points = gpd.read_file(str(self.split_points_gpkg), engine="fiona")

        # Identify outlet reach (NextDownID == -1)
        outlet_segs = split_flows[split_flows["NextDownID"] == -1]
        if len(outlet_segs) != 1:
            log.info(
                "OutletBackpoolMitigate: %d segments with NextDownID=-1, skipping",
                len(outlet_segs),
            )
            return False

        with rasterio.open(str(self.catchment_pixels_path)) as src:
            catch_data = src.read(1)

        # Criteria 1: outlier catchment size
        flagged, outlier_ids = _catch_size_outliers(catch_data)
        if not flagged:
            log.info("OutletBackpoolMitigate: no catchment size outliers detected")
            return False

        # Criteria 2: outlier at outlet
        outlet_row = outlet_segs.iloc[0]
        last_pt = Point(outlet_row.geometry.coords[-1])

        with rasterio.open(str(self.catchment_pixels_path)) as src:
            transform = src.transform
            col_f, row_f = ~transform * (last_pt.x, last_pt.y)
            outlet_catch_id = int(catch_data[int(row_f), int(col_f)])

        if outlet_catch_id not in outlier_ids:
            log.info(
                "OutletBackpoolMitigate: outlier catchment not at outlet — skipping"
            )
            return False

        log.info(
            "OutletBackpoolMitigate: backpool detected (catchment ID=%d) — trimming outlet reach",
            outlet_catch_id,
        )

        # Trim: snap outlet reach to penultimate vertex
        coords = list(outlet_row.geometry.coords)
        if len(coords) >= 3:
            trim_pt = Point(coords[-3])
        elif len(split_flows) > 1:
            # fall back to last point of second-to-last segment
            node_2tl = outlet_row["From_Node"]
            seg_2tl = split_flows[split_flows["To_Node"] == node_2tl]
            if seg_2tl.empty:
                log.warning(
                    "OutletBackpoolMitigate: cannot find second-to-last segment — skipping"
                )
                return False
            trim_pt = Point(list(seg_2tl.iloc[0].geometry.coords)[-1])
        else:
            log.warning(
                "OutletBackpoolMitigate: outlet reach too short to trim — skipping"
            )
            return False

        trim_pt_gdf = gpd.GeoDataFrame([{"geometry": trim_pt}], crs=split_flows.crs)
        trim_pt_snapped = split_flows.iloc[[outlet_segs.index[0]]].interpolate(
            split_flows.iloc[[outlet_segs.index[0]]].project(trim_pt_gdf.geometry)
        )
        trim_pt_buf = trim_pt_snapped.iloc[0].buffer(1)

        split_result = shapely_ops.split(outlet_row.geometry, trim_pt_buf)
        if len(list(split_result.geoms)) > 1:
            longest = max(split_result.geoms, key=lambda g: g.length)
            split_flows = split_flows.copy()
            split_flows.loc[outlet_segs.index[0], "geometry"] = longest

            # Recalculate slope and length for trimmed segment
            with rasterio.open(str(self.dem_path)) as dem_ds:
                seg_geom = split_flows.loc[outlet_segs.index[0], "geometry"]
                p0 = seg_geom.coords[0]
                p1 = seg_geom.coords[-1]
                try:
                    e0, e1 = [
                        v[0] for v in rasterio.sample.sample_gen(dem_ds, [p0, p1])
                    ]
                    slope = max(
                        abs(e0 - e1) / max(seg_geom.length, 1e-9), self.slope_min
                    )
                except Exception:
                    slope = self.slope_min
            split_flows.loc[outlet_segs.index[0], "S0"] = slope
            split_flows.loc[outlet_segs.index[0], "LengthKm"] = seg_geom.length * 1e-3

        # Filter split points to those within trimmed flow buffer
        trim_buf = split_flows.buffer(10).geometry.union_all()
        split_points = split_points[split_points.geometry.within(trim_buf)]

        # Mask outlier catchment from both rasters
        catch_poly_gdf = _polygonize_catchments(self.catchment_pixels_path)
        if catch_poly_gdf is not None and len(catch_poly_gdf) > 0:
            filtered = catch_poly_gdf[catch_poly_gdf["HydroID"] != outlet_catch_id]
            if len(filtered) > 0:
                new_boundary = filtered.dissolve()
                boundary_json = [new_boundary.iloc[0].geometry.__geo_interface__]
                _mask_raster_to_boundary(
                    self.catchment_reaches_path,
                    boundary_json,
                    self.catchment_reaches_path,
                )
                _mask_raster_to_boundary(
                    self.catchment_pixels_path,
                    boundary_json,
                    self.catchment_pixels_path,
                )

        # Save updated vectors
        split_flows.to_file(
            str(self.split_flows_gpkg), driver="GPKG", index=False, engine="fiona"
        )
        split_points.to_file(
            str(self.split_points_gpkg), driver="GPKG", index=False, engine="fiona"
        )

        log.info("OutletBackpoolMitigate: mitigation applied — files updated")
        return True


# Internal utilis
def _catch_size_outliers(
    catch_data: np.ndarray,
) -> tuple[bool, list[int]]:
    """Return (flagged, outlier_ids) based on 1-std-dev threshold."""
    unique, counts = np.unique(catch_data, return_counts=True)
    # remove background (0)
    mask = unique > 0
    unique = unique[mask]
    counts = counts[mask]

    if len(counts) < 2:
        return False, []

    mean_c = counts.mean()
    std_c = counts.std()
    outlier_mask = np.abs(counts - mean_c) > std_c
    outlier_ids = unique[outlier_mask].tolist()

    if outlier_ids:
        log.info(
            "  catchment size outliers: %d found (mean=%.0f, std=%.0f)",
            len(outlier_ids),
            mean_c,
            std_c,
        )
        return True, outlier_ids
    return False, []


def _polygonize_catchments(raster_path: Path) -> Optional[gpd.GeoDataFrame]:
    """Polygonize integer raster to GeoDataFrame with HydroID column."""
    try:
        with rasterio.open(str(raster_path)) as src:
            data = src.read(1)
            transform = src.transform
            crs = src.crs
            nodata = src.nodata

        mask = data != (int(nodata) if nodata is not None else 0)
        shapes = list(rasterio.features.shapes(data, mask=mask, transform=transform))

        geoms = []
        vals = []
        for geom, val in shapes:
            from shapely.geometry import shape

            geoms.append(shape(geom))
            vals.append(int(val))

        return gpd.GeoDataFrame({"HydroID": vals, "geometry": geoms}, crs=crs)
    except Exception as exc:
        log.warning("_polygonize_catchments failed: %s", exc)
        return None


def _mask_raster_to_boundary(
    raster_path: Path, boundary_json: list, save_path: Path
) -> None:
    """Mask a raster to a geometry boundary and save in-place."""
    import shutil

    from rasterio.mask import mask as rio_mask

    tmp = save_path.with_suffix(".tmp.tif")
    try:
        with rasterio.open(str(raster_path)) as src:
            profile = src.profile.copy()
            profile.update(
                compress="lzw",
                tiled=True,
                blockxsize=512,
                blockysize=512,
                BIGTIFF="YES",
            )
            masked, _ = rio_mask(src, boundary_json, crop=False)
        with rasterio.open(str(tmp), "w", **profile) as dst:
            dst.write(masked[0], 1)
        shutil.move(str(tmp), str(save_path))
    except Exception as exc:
        log.warning("_mask_raster_to_boundary failed: %s", exc)
        if tmp.exists():
            tmp.unlink()
