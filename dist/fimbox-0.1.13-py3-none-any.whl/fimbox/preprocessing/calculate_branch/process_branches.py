"""
Author: Supath Dhital
Date Updated: June 2026

Multi-branch processing.

Pipeline
--------
1. Read the AOI's branch list.
2. AOI-level USGS gage assignment (when ``usgs_gages_gpkg`` is provided).
3. Branch-zero post-CreateHAND tasks: USGS crosswalk and deny-list cleanup.
4. For every non-zero branch in parallel (ProcessPoolExecutor):
       a. BranchZero raster prep for the branch (DEM clip + AGREE)
       b. adjust_floodplains (optional, when FEMA NFHL gpkg is provided)
       c. CreateHAND (22-step HAND pipeline)
       d. run_branch_crosswalk (USGS gage --> HydroID --> DEM elevations)
       e. per-branch deny-list cleanup (default-on; uses
          ``fimbox/config/deny_branches.lst``)
       f. per-branch log file: ``<aoi_dir>/logs/branch/<aoi_id>_branch_<bid>.log``
5. Per-branch error handling:
       - exit code 61 (no valid flowlines) --> branch dir wiped, run continues
       - exit code 64 (no crosswalks)      --> branch dir wiped, run continues
       - other unhandled exception          --> branch logged as failed,
                                               run continues

Logging
-------
Each worker process re-attaches the case logger so its records land in the
AOI's combined ``processing.log`` (at the AOI root) AND in a per-branch
``<aoi_dir>/logs/branch/<aoi_id>_branch_<bid>.log`` (attached for the
duration of that worker only). The shared format is the standard fimbox
``HH:MM:SS [LEVEL] message``.

Failures go to both files too: a branch that dies is logged at ERROR with the
traceback of the step that raised, and so is a crash that takes the whole run
down. Nothing fails only on the terminal.

Inputs
------
aoi_dir              <aoi_dir>/                 (output of getAllInputData + BranchDerivation)
branch_list          <aoi_dir>/branch_list.csv  (default location, override via param)
fema_nfhl_gpkg       optional, for adjust_floodplains
usgs_gages_gpkg      optional, for gage crosswalk
delete_deny_list     True (default) deletes branch-zero, per-branch, and AOI
                     intermediates from fimbox/config/deny_*.lst; False keeps everything.

Outputs
-------
For every successful branch B:
    <aoi_dir>/branches/<B>/  ... full BranchZero + HAND outputs (most
                                 intermediates removed when delete_deny_list=True)
    <aoi_dir>/branches/<B>/usgs_elev_table.csv  (when gages were provided)
    <aoi_dir>/logs/branch/<aoi_id>_branch_<B>.log
"""

from __future__ import annotations

import csv
import logging
import time
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Sequence, Union

from ..._aoi_lock import aoi_write_lock
from ..._workers import RAM_PER_WORKER_BRANCH_GB, resolve_workers
from ...logging_utils import already_logged, aoi_root, attach_case_log, log_errors
from ..source_naming import detect_identifier, resolve_source, source_name
from .adjust_floodplains import adjust_floodplains
from .calculate_branchzero import BranchZero
from .create_hand import CreateHAND
from .gage_crosswalk import assign_gages_to_branches, run_branch_crosswalk

log = logging.getLogger(__name__)

PathLike = Union[str, Path]


# Per-branch exit-code conventions used by the error classifier below.
EXIT_OK = 0
EXIT_NO_FLOWLINES = 61
EXIT_NO_CROSSWALK = 64
EXIT_TOO_MANY_HYDROIDS = 65


def _published_xsec_locations() -> Optional[Path]:
    # Best-effort: a fetch failure just means the cross-section crosswalk is
    # skipped, which is the same outcome as not having the file.
    from ...datasets import fetch

    return fetch("xsec_locations")


@dataclass
class BranchResult:
    branch_id: str
    status: str  # "ok" | "no_flowlines" | "no_crosswalk" | "too_many_hydroids" | "failed" | "killed"
    elapsed_s: float
    error: Optional[str] = None


class AOIProcessingConfig:
    """Inputs the orchestrator needs to run every branch.

    The AOI identifier is optional. When omitted it defaults to the AOI folder
    name (the parent of ``watershed-data``), so it always matches the data being
    processed. Pass it explicitly — as ``aoi_id`` (any drainage area) or
    ``huc_id`` (a USGS HUC8) — only to record a specific id. It is stored under
    ``self.aoi_id``; ``self.huc_id`` is an alias returning the same value::

        AOIProcessingConfig(aoi_dir=".../my_basin")              # id = "my_basin"
        AOIProcessingConfig(aoi_dir=..., huc_id="08060202")      # id = "08060202"
        AOIProcessingConfig(aoi_dir=..., aoi_id="MyBasin")       # id = "MyBasin"
    """

    def __init__(
        self,
        *,
        aoi_dir: Optional[Path] = None,
        huc_dir: Optional[Path] = None,
        aoi_id: Optional[str] = None,
        huc_id: Optional[str] = None,
        branch_list_path: Optional[Path] = None,
        # required per-branch inputs
        dem_path: Optional[Path] = None,
        streams_gpkg: Optional[Path] = None,
        boundary_gpkg: Optional[Path] = None,
        catchments_gpkg: Optional[Path] = None,
        levelpaths_gpkg: Optional[Path] = None,
        # optional per-branch inputs
        bridge_elev_diff_path: Optional[Path] = None,
        levee_gpkg_path: Optional[Path] = None,
        levee_raster_path: Optional[Path] = None,
        headwaters_gpkg: Optional[Path] = None,
        levelpaths_extended_gpkg: Optional[Path] = None,
        fema_nfhl_gpkg: Optional[Path] = None,
        branch_polygons_gpkg: Optional[Path] = None,
        # USGS crosswalk inputs
        usgs_gages_gpkg: Optional[Path] = None,
        ahps_gpkg: Optional[Path] = None,
        ras_locs_gpkg: Optional[Path] = None,  # unset -> published locations
        # CRS / numeric
        target_crs: Union[str, int] = 5070,
        branch_zero_id: str = "0",
        # AGREE and floodplain adjustment defaults
        agree_buffer_m: float = 15.0,
        agree_smooth_drop: float = 10.0,
        agree_sharp_drop: float = 1000.0,
        floodplain_distance_threshold: float = 7.0,
        floodplain_slope_exponent: float = 1.0,
        floodplain_z_factor: float = 0.5,
        fema_floodplain_layer: str = "combined",
        # CreateHAND tuning — applied to EVERY branch so branch zero and the
        # non-zero branches share one set of values. Defaults mirror CreateHAND;
        # override here to retune the whole AOI in one place.
        cost_distance_tolerance: float = 50.0,
        lateral_elevation_threshold: int = 10,
        max_split_distance_m: float = 1500.0,
        slope_min: float = 0.0001,
        lakes_buffer_dist_m: float = 100.0,
        # SRC / crosswalk tuning (drive step 18-19, the hydroTable).
        mannings_n: float = 0.06,
        stage_min_m: float = 0.0,
        stage_interval_m: float = 0.3048,
        stage_max_m: float = 25.2984,
        min_catchment_area: float = 0.25,
        min_stream_length: float = 0.5,
        crosswalk_max_distance_m: float = 100.0,
        # SRC slope source: "dem" (default) | "hfab".
        src_slope_source: str = "dem",
        hfab_slope_column: Optional[str] = None,
        evaluate_crosswalk: bool = False,
        convert_to_int16: bool = False,
        # gage crosswalk schema
        gage_aoi_filter_column: str = "HUC8",
        # branch-zero post-CreateHAND steps
        run_branch_zero_usgs_crosswalk: bool = False,
        delete_deny_list: bool = True,
        # When True, keep the output dir of branches that fail with
        # no_flowlines / no_crosswalk / too_many_hydroids instead of wiping
        # it. Useful for debugging why a branch produced no streams.
        keep_failed_branches: bool = False,
        deny_branch_zero_list: Optional[Path] = None,
        deny_branches_list: Optional[Path] = None,
        # parallelism — None/0 sizes to the machine, 1 is serial, and a number
        # bigger than CPU/RAM can feed is clamped instead of obeyed.
        n_workers: Optional[int] = None,
        timeout_seconds: Optional[int] = None,
    ):
        self.aoi_dir = _pick_one("aoi_dir", aoi_dir, "huc_dir", huc_dir, required=True)
        # aoi_id is optional: when omitted it defaults to the AOI folder name
        # (the parent of watershed-data), so the label always matches the data
        # being processed. Pass it explicitly only to record a specific id.
        self.aoi_id = (
            _pick_one("aoi_id", aoi_id, "huc_id", huc_id, required=False)
            or aoi_root(self.aoi_dir).name
        )
        self.branch_list_path = branch_list_path
        self.dem_path = dem_path
        self.streams_gpkg = streams_gpkg
        self.boundary_gpkg = boundary_gpkg
        self.catchments_gpkg = catchments_gpkg
        self.levelpaths_gpkg = levelpaths_gpkg
        self.bridge_elev_diff_path = bridge_elev_diff_path
        self.levee_gpkg_path = levee_gpkg_path
        self.levee_raster_path = levee_raster_path
        self.headwaters_gpkg = headwaters_gpkg
        self.levelpaths_extended_gpkg = levelpaths_extended_gpkg
        self.fema_nfhl_gpkg = fema_nfhl_gpkg
        self.branch_polygons_gpkg = branch_polygons_gpkg
        self.usgs_gages_gpkg = usgs_gages_gpkg
        self.ahps_gpkg = ahps_gpkg
        # Unset means "use the published cross-section locations". Without them the
        # crosswalk writes no ras_elev_table, and the cross-section calibration step
        # has nothing to key on, so it would silently never run.
        self.ras_locs_gpkg = ras_locs_gpkg or _published_xsec_locations()
        self.target_crs = target_crs
        self.branch_zero_id = branch_zero_id
        self.agree_buffer_m = agree_buffer_m
        self.agree_smooth_drop = agree_smooth_drop
        self.agree_sharp_drop = agree_sharp_drop
        self.floodplain_distance_threshold = floodplain_distance_threshold
        self.floodplain_slope_exponent = floodplain_slope_exponent
        self.floodplain_z_factor = floodplain_z_factor
        self.fema_floodplain_layer = fema_floodplain_layer

        # CreateHAND tuning (shared by every branch via the CreateHAND call).
        self.cost_distance_tolerance = cost_distance_tolerance
        self.lateral_elevation_threshold = lateral_elevation_threshold
        self.max_split_distance_m = max_split_distance_m
        self.slope_min = slope_min
        self.lakes_buffer_dist_m = lakes_buffer_dist_m
        self.mannings_n = mannings_n
        self.stage_min_m = stage_min_m
        self.stage_interval_m = stage_interval_m
        self.stage_max_m = stage_max_m
        self.min_catchment_area = min_catchment_area
        self.min_stream_length = min_stream_length
        self.crosswalk_max_distance_m = crosswalk_max_distance_m
        self.src_slope_source = src_slope_source
        self.hfab_slope_column = hfab_slope_column
        self.evaluate_crosswalk = evaluate_crosswalk
        self.convert_to_int16 = convert_to_int16
        self.gage_aoi_filter_column = gage_aoi_filter_column
        self.run_branch_zero_usgs_crosswalk = run_branch_zero_usgs_crosswalk
        self.keep_failed_branches = bool(keep_failed_branches)
        self.delete_deny_list = bool(delete_deny_list)
        self.deny_branch_zero_list = (
            Path(deny_branch_zero_list) if deny_branch_zero_list else None
        )
        self.deny_branches_list = (
            Path(deny_branches_list) if deny_branches_list else None
        )
        self.n_workers = n_workers
        self.timeout_seconds = timeout_seconds

    @property
    def huc_dir(self) -> Path:
        return self.aoi_dir

    @property
    def huc_id(self) -> str:
        return self.aoi_id


def _pick_one(name_a: str, val_a, name_b: str, val_b, *, required: bool):
    """Accept either of two equivalent kwargs but not both at once."""
    if val_a is not None and val_b is not None and val_a != val_b:
        raise TypeError(
            f"Pass either {name_a}= or {name_b}=, not both with different values "
            f"({val_a!r} vs {val_b!r})."
        )
    chosen = val_a if val_a is not None else val_b
    if required and chosen is None:
        raise TypeError(f"Either {name_a}= or {name_b}= must be provided.")
    return chosen


# Backwards-compatible alias: HucProcessingConfig is the same class.
HucProcessingConfig = AOIProcessingConfig


def process_branches(
    cfg: AOIProcessingConfig, *, include_branch_zero: bool = False
) -> list[BranchResult]:
    # One writer per AOI. This and calibration both rewrite the per-branch SRCs
    # and hydroTables in place, so a second run over the same AOI would
    # interleave with this one and splice the CSVs.
    attach_case_log(cfg.aoi_dir)
    with log_errors(f"Branch processing {cfg.aoi_id}"):
        with aoi_write_lock(cfg.aoi_dir, "branch processing"):
            return _process_branches(cfg, include_branch_zero=include_branch_zero)


def _process_branches(
    cfg: AOIProcessingConfig, *, include_branch_zero: bool = False
) -> list[BranchResult]:
    """Run the branch loop in parallel.

    Pure branch calculation: BranchZero, adjust_floodplains, CreateHAND,
    USGS crosswalk, per-branch, branch-zero cleanup.

    With ``include_branch_zero=True`` branch zero joins the same pool instead of
    being run to completion ahead of it. Its raster prep and CreateHAND cover the
    whole AOI, so together they are the longest work in the run and nothing else
    reads their outputs — holding the other branches back until they finish
    wastes every other core. The caller only has to have published the shared
    AOI-root rasters first (``BranchZero.publish_shared_inputs``), which is what
    the siblings clip from. Note that ``cfg.timeout_seconds``, if set, now also
    applies to branch zero, and it needs a far longer leash than a single level
    path.

    Calibration is NOT invoked here — run it explicitly via ``fimbox.run_calibration`` once
    the branch loop and any deny-list cleanups are complete.

    Returns the per-branch results list (caller can inspect statuses)."""
    cfg = _resolve_paths(cfg)
    attach_case_log(cfg.aoi_dir)

    start = time.time()
    log.info(f"=== process_branches: {cfg.aoi_id} ===")
    log.info(f"Branch list: {cfg.branch_list_path}")

    # Stage 0: AOI-level USGS gage assignment
    if cfg.usgs_gages_gpkg and cfg.levelpaths_gpkg:
        log.info("--- USGS gage assignment (AOI level) ---")
        try:
            assign_gages_to_branches(
                usgs_gages_gpkg=cfg.usgs_gages_gpkg,
                nwm_streams_levelpaths_gpkg=cfg.levelpaths_gpkg,
                aoi_id=cfg.aoi_id,
                out_dir=cfg.aoi_dir,
                target_crs=cfg.target_crs,
                branch_zero_id=cfg.branch_zero_id,
                ras_locs_gpkg=cfg.ras_locs_gpkg,
                ahps_gpkg=cfg.ahps_gpkg,
                aoi_filter_column=cfg.gage_aoi_filter_column,
            )
        except Exception as exc:
            log.error(f"USGS gage assignment failed: {exc}", exc_info=True)

    branch_ids = _read_branch_list(cfg.branch_list_path, cfg.branch_zero_id)
    log.info(f"Branches to process (excluding branch zero): {len(branch_ids)}")
    if not branch_ids:
        log.warning("No non-zero branches found — only branch zero will exist.")

    # Branch zero goes in first: it is the whole-AOI task, so starting the
    # longest job before the short ones keeps the tail of the run from being
    # one lonely branch on one core (longest-processing-time-first).
    dispatch_ids = (
        [cfg.branch_zero_id] + branch_ids if include_branch_zero else branch_ids
    )

    # Resolved against the machine: None/0 -> as many as CPU+RAM allow, an
    # over-ambitious request -> clamped, 1 -> the serial path below. Never more
    # workers than branches, so a 3-branch AOI doesn't spin up 12 processes.
    n_workers = resolve_workers(
        cfg.n_workers,
        n_tasks=len(dispatch_ids) or None,
        ram_per_worker_gb=RAM_PER_WORKER_BRANCH_GB,
        label="Branch processing",
    )

    results: list[BranchResult] = []
    if dispatch_ids and n_workers <= 1:
        # True serial path: one branch at a time, no Dask. Use n_workers=1 to
        # isolate concurrency effects from deterministic per-branch behaviour.
        log.info("Processing %d branches serially (n_workers=1)", len(dispatch_ids))
        for bid in dispatch_ids:
            results.append(_process_single_branch(cfg, bid))
    elif dispatch_ids:
        from distributed import as_completed as dask_as_completed

        from ..._dask import get_client
        from ._wbt_safe import _ensure_wbt_source

        _ensure_wbt_source(cfg.wbt_path if hasattr(cfg, "wbt_path") else None)

        client = get_client(n_workers=n_workers)
        log.info(
            "Dispatching %d branches to Dask (%d workers, dashboard %s)",
            len(dispatch_ids),
            len(client.scheduler_info()["workers"]),
            client.dashboard_link,
        )
        # retries=0 is critical: when a branch OOMs and Dask kills the worker,
        # the default behaviour retries on 3 more workers and OOMs each in
        # turn (the KilledWorker storm seen in real-world runs). Setting it
        # to 0 makes the failure surface immediately so we record one
        # 'failed' result and move on to siblings.
        futures = client.map(
            _process_single_branch,
            [cfg] * len(dispatch_ids),
            dispatch_ids,
            pure=False,
            retries=0,
        )
        future_to_bid = {fut.key: bid for fut, bid in zip(futures, dispatch_ids)}
        for fut in dask_as_completed(futures):
            bid = future_to_bid.get(fut.key, "?")
            try:
                results.append(fut.result(timeout=cfg.timeout_seconds))
            except Exception as exc:
                # KilledWorker / OOM / unhandled exception
                exc_text = str(exc)
                status = (
                    "killed"
                    if "KilledWorker" in type(exc).__name__
                    or "killed" in exc_text.lower()
                    else "failed"
                )
                log.error(
                    f"Branch {bid} crashed in worker (status={status}): {exc}",
                    exc_info=True,
                )
                results.append(
                    BranchResult(
                        branch_id=bid, status=status, elapsed_s=0.0, error=exc_text
                    )
                )

    branches_elapsed = time.time() - start
    _log_branch_summary(results, branches_elapsed)

    # Branch-zero crosswalk waits until the loop drains — it reads branch zero's
    # CreateHAND outputs, which may have just been produced inside the pool.
    _run_branch_zero_post_steps(cfg)

    # Per-branch + branch-zero deny-list cleanup runs once here, after
    # every branch has finished, instead of inside each worker. Tests
    # that consume intermediates (e.g. test_branchprocessing.py) can
    # set cfg.delete_deny_list=False to skip this entirely.
    _cleanup_after_all(cfg, results)

    total_elapsed = time.time() - start
    log.info(f"=== AOI processing complete: {cfg.aoi_id} ({total_elapsed:.1f}s) ===")
    return results


def _cleanup_after_all(
    cfg: AOIProcessingConfig, results: Sequence[BranchResult]
) -> None:
    if not cfg.delete_deny_list:
        log.info("Per-branch + branch-zero cleanup disabled (delete_deny_list=False)")
        return

    from .calculate_allbranches import _bundled_deny_list
    from .outputs_cleanup import remove_deny_list_files

    branches_root = cfg.aoi_dir / "branches"
    bzero_dir = branches_root / cfg.branch_zero_id

    # Branch zero.
    if bzero_dir.is_dir():
        deny_bz = cfg.deny_branch_zero_list or _bundled_deny_list(
            "deny_branch_zero.lst"
        )
        if deny_bz is not None and Path(deny_bz).is_file():
            log.info(f"--- branch-zero outputs cleanup ({Path(deny_bz).name}) ---")
            try:
                remove_deny_list_files(
                    src_dir=bzero_dir,
                    deny_list=deny_bz,
                    branch_id=cfg.branch_zero_id,
                    identifier=detect_identifier(cfg.aoi_dir),
                    verbose=True,
                )
            except Exception as exc:
                log.warning(f"Branch-zero cleanup skipped: {exc}")
        else:
            log.info("Branch-zero deny list not found — skipping cleanup")

    # Non-zero branches that finished ok.
    deny_br = cfg.deny_branches_list or _bundled_deny_list("deny_branches.lst")
    if deny_br is None or not Path(deny_br).is_file():
        log.info("Per-branch deny list not found — skipping cleanup")
        return

    log.info(f"--- per-branch outputs cleanup ({Path(deny_br).name}) ---")
    aoi_identifier = detect_identifier(cfg.aoi_dir)
    for r in results:
        if r.status != "ok" or r.branch_id == cfg.branch_zero_id:
            continue
        branch_dir = branches_root / r.branch_id
        if not branch_dir.is_dir():
            continue
        try:
            remove_deny_list_files(
                src_dir=branch_dir,
                deny_list=deny_br,
                branch_id=r.branch_id,
                identifier=aoi_identifier,
                verbose=False,
            )
        except Exception as exc:
            log.warning(f"Branch {r.branch_id} cleanup skipped: {exc}")


def _resolve_paths(cfg: AOIProcessingConfig) -> AOIProcessingConfig:
    """Fill in missing default paths from the case directory."""
    d = cfg.aoi_dir
    if cfg.branch_list_path is None:
        # BranchDerivation writes branch_ids.lst, which the branch loop reads.
        # branch_list.csv is kept as a legacy fallback for older AOIs.
        for candidate in ("branch_ids.lst", "branch_list.csv"):
            p = d / candidate
            if p.is_file():
                cfg.branch_list_path = p
                break
        else:
            cfg.branch_list_path = d / "branch_ids.lst"
    cfg.dem_path = cfg.dem_path or d / "dem.tif"
    # Source files carry an identifier prefix (default "nwm"); resolve by suffix
    # so a custom-identifier staging directory works without extra config.
    cfg.streams_gpkg = cfg.streams_gpkg or resolve_source(d, "streams")
    cfg.boundary_gpkg = cfg.boundary_gpkg or d / "wbd8_clp.gpkg"
    cfg.catchments_gpkg = cfg.catchments_gpkg or resolve_source(d, "catchments")
    cfg.levelpaths_gpkg = cfg.levelpaths_gpkg or resolve_source(d, "lp_streams")
    cfg.branch_polygons_gpkg = cfg.branch_polygons_gpkg or d / "branch_polygons.gpkg"
    if cfg.headwaters_gpkg is None:
        hw = resolve_source(d, "headwaters_points")
        cfg.headwaters_gpkg = hw if hw.exists() else None
        if cfg.headwaters_gpkg is None:
            hw = resolve_source(d, "headwaters")
            cfg.headwaters_gpkg = hw if hw.exists() else None
    if cfg.levee_gpkg_path is None:
        lg = d / "3d_nld_subset_levees_burned.gpkg"
        cfg.levee_gpkg_path = lg if lg.exists() else None
    return cfg


def _read_branch_list(path: Path, branch_zero_id: str) -> list[str]:
    """Read branch_list.csv (rows: ``aoi_id,levpa_id``) excluding branch zero."""
    if not path.is_file():
        return []
    branches: list[str] = []
    with open(path, newline="") as fh:
        for row in csv.reader(fh):
            if not row:
                continue
            # accept either 1-col (just branch id) or 2-col (aoi_id,branch_id)
            bid = row[-1].strip()
            if bid and bid != branch_zero_id:
                branches.append(bid)
    return branches


def _run_branch_zero_post_steps(cfg: AOIProcessingConfig) -> None:
    """Run the branch-zero USGS crosswalk and deny-list cleanup.

    USGS crosswalk is opt-in (``cfg.run_branch_zero_usgs_crosswalk``).
    Deny-list cleanup runs by default (``cfg.delete_deny_list=True``) and uses
    ``cfg.deny_branch_zero_list`` when set, otherwise falls back to
    ``fimbox/config/deny_branch_zero.lst``. Pass ``delete_deny_list=False`` on
    the config to keep every intermediate.

    Every step is a no-op when its required inputs are missing or when branch
    zero's directory hasn't been populated yet (which is fine — call this
    after running branch-zero CreateHAND).
    """
    branch_dir = cfg.aoi_dir / "branches" / cfg.branch_zero_id
    if not branch_dir.is_dir():
        return

    # USGS crosswalk for branch zero. The branch-zero gpkg is the assignment
    # output with `levpa_id` overwritten to "0", so every gage in the AOI is
    # eligible for branch-zero rating-curve calibration.
    if cfg.run_branch_zero_usgs_crosswalk:
        bzero_gages = cfg.aoi_dir / f"usgs_subset_gages_{cfg.branch_zero_id}.gpkg"
        catchments_xwalk = (
            branch_dir / f"gw_catchments_reaches_filtered_addedAttributes_crosswalked_"
            f"{cfg.branch_zero_id}.gpkg"
        )
        flows = (
            branch_dir / f"demDerived_reaches_split_filtered_{cfg.branch_zero_id}.gpkg"
        )
        dem_b = branch_dir / f"dem_meters_{cfg.branch_zero_id}.tif"
        dem_adj = branch_dir / f"dem_thalwegCond_{cfg.branch_zero_id}.tif"
        if not dem_b.exists():
            dem_b = branch_dir / f"dem_{cfg.branch_zero_id}.tif"

        if all(
            p.exists() for p in (bzero_gages, catchments_xwalk, flows, dem_b, dem_adj)
        ):
            log.info("--- USGS crosswalk (branch zero) ---")
            try:
                run_branch_crosswalk(
                    aoi_gages_gpkg=bzero_gages,
                    branch_catchments_gpkg=catchments_xwalk,
                    branch_flows_gpkg=flows,
                    dem_path=dem_b,
                    dem_thalweg_path=dem_adj,
                    branch_id=cfg.branch_zero_id,
                    out_dir=branch_dir,
                    target_crs=cfg.target_crs,
                )
            except Exception as exc:
                log.warning(f"Branch-zero USGS crosswalk skipped: {exc}")
        else:
            log.info("Branch-zero USGS crosswalk: required inputs missing — skipping")

    # Branch-zero deny-list cleanup is deferred to _cleanup_after_all,
    # which runs once after every branch (zero and non-zero) finishes.


def _process_single_branch(cfg: AOIProcessingConfig, branch_id: str) -> BranchResult:
    """Per-branch worker. Runs in its own process; re-attaches the case log
    so its output reaches the shared processing.log AND a per-branch log file
    under ``<aoi_dir>/logs/branch/<aoi_id>_branch_<branch_id>.log``."""
    attach_case_log(cfg.aoi_dir)
    branch_log = logging.getLogger(__name__)

    # Per-branch log file, attached to the fimbox root logger so every record
    # this worker emits is captured. Detached again in the finally-block.
    branch_log_path = (
        cfg.aoi_dir / "logs" / "branch" / f"{cfg.aoi_id}_branch_{branch_id}.log"
    )
    branch_log_path.parent.mkdir(parents=True, exist_ok=True)
    branch_log_handler = logging.FileHandler(branch_log_path, mode="a")
    branch_log_handler.setFormatter(
        logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
    )
    logging.getLogger("fimbox").addHandler(branch_log_handler)

    started = time.time()
    branch_log.info(f"--- Branch {branch_id} start ---")
    branch_dir = cfg.aoi_dir / "branches" / branch_id
    branch_dir.mkdir(parents=True, exist_ok=True)

    try:
        # Source-file prefix (default "nwm"), detected from the staged data so
        # per-branch derivative filenames match the AOI-level ones.
        identifier = detect_identifier(cfg.aoi_dir)

        # Non-zero branches clip to their own polygon (level-path buffer)
        # rather than the full AOI boundary. Branch 0 keeps the AOI
        # boundary because it covers the whole area.
        branch_boundary = cfg.boundary_gpkg
        branch_streams = cfg.streams_gpkg
        branch_headwaters = cfg.headwaters_gpkg
        branch_levelpaths_extended = cfg.levelpaths_extended_gpkg
        if branch_id != cfg.branch_zero_id:
            single = _write_single_branch_polygon(
                cfg.branch_polygons_gpkg, branch_id, branch_dir
            )
            if single is not None:
                branch_boundary = single
                branch_log.info(f"Using per-branch clip polygon: {single.name}")
            else:
                branch_log.warning(
                    "branch_polygons.gpkg missing or has no row for "
                    f"branch {branch_id} — falling back to AOI boundary"
                )

            streams_src = resolve_source(cfg.aoi_dir, "lp_streams", identifier)
            filtered_streams = _filter_by_levpa_id(
                streams_src,
                branch_id,
                branch_dir,
                source_name("lp_streams", identifier, branch_id),
            )
            if filtered_streams is not None:
                branch_streams = filtered_streams

            ext_src = resolve_source(cfg.aoi_dir, "lp_streams_extended", identifier)
            filtered_ext = _filter_by_levpa_id(
                ext_src,
                branch_id,
                branch_dir,
                source_name("lp_streams_extended", identifier, branch_id),
            )
            if filtered_ext is not None:
                branch_levelpaths_extended = filtered_ext

            hw_src = resolve_source(
                cfg.aoi_dir, "lp_streams_dissolved_headwaters", identifier
            )
            filtered_hw = _filter_by_levpa_id(
                hw_src,
                branch_id,
                branch_dir,
                source_name("lp_streams_dissolved_headwaters", identifier, branch_id),
            )
            if filtered_hw is not None:
                branch_headwaters = filtered_hw

            cat_src = resolve_source(cfg.aoi_dir, "lp_catchments", identifier)
            _filter_by_levpa_id(
                cat_src,
                branch_id,
                branch_dir,
                source_name("lp_catchments", identifier, branch_id),
            )

        _bz_sentinel = branch_dir / "branch_zero_complete.txt"
        if _bz_sentinel.exists():
            branch_log.info("BranchZero already complete — skipping raster prep")
        else:
            BranchZero(
                dem_path=cfg.dem_path,
                streams_gpkg=branch_streams,
                boundary_gpkg=branch_boundary,
                out_dir=cfg.aoi_dir,
                bridge_elev_diff_path=cfg.bridge_elev_diff_path,
                levee_gpkg_path=cfg.levee_gpkg_path,
                levee_raster_path=cfg.levee_raster_path,
                headwaters_gpkg=branch_headwaters,
                levelpaths_extended_gpkg=branch_levelpaths_extended,
                target_crs=(
                    f"EPSG:{cfg.target_crs}"
                    if str(cfg.target_crs).isdigit()
                    else cfg.target_crs
                ),
                agree_buffer_m=cfg.agree_buffer_m,
                agree_smooth_drop=cfg.agree_smooth_drop,
                agree_sharp_drop=cfg.agree_sharp_drop,
                branch_zero_id=branch_id,
            ).run()

        # adjust_floodplains is optional (requires NFHL gpkg + branch polygons)
        if cfg.fema_nfhl_gpkg and cfg.branch_polygons_gpkg.exists():
            dem_burned = branch_dir / f"dem_burned_{branch_id}.tif"
            flows_bool = branch_dir / f"flows_grid_boolean_{branch_id}.tif"
            if dem_burned.exists() and flows_bool.exists():
                try:
                    adjust_floodplains(
                        input_file=flows_bool,
                        dem_file=dem_burned,
                        nwm_catchments=cfg.catchments_gpkg,
                        nwm_streams=cfg.streams_gpkg,
                        nwm_levelpaths=cfg.levelpaths_gpkg,
                        distance_file=branch_dir
                        / f"flows_grid_boolean_euclidean_distance_{branch_id}.tif",
                        output_file=branch_dir / f"dem_burned_adjusted_{branch_id}.tif",
                        distance_threshold=cfg.floodplain_distance_threshold,
                        slope_exponent=cfg.floodplain_slope_exponent,
                        z_factor=cfg.floodplain_z_factor,
                        branch_polygons=cfg.branch_polygons_gpkg,
                        branch_id=branch_id,
                        fema_flood_zones_file=cfg.fema_nfhl_gpkg,
                        fema_flood_zones_layer=cfg.fema_floodplain_layer,
                    )
                except Exception as exc:
                    branch_log.warning(
                        f"adjust_floodplains skipped for branch {branch_id}: {exc}"
                    )

        # CreateHAND: All steps. aoi_code is not passed — CreateHAND derives it
        # from aoi_dir for the catchment boundary filter.
        CreateHAND(
            aoi_dir=cfg.aoi_dir,
            branch_dir=branch_dir,
            branch_id=branch_id,
            levee_protected_areas_gpkg=None,  # set by user if needed
            levee_levelpaths_csv=None,
            lakes_gpkg=(
                resolve_source(cfg.aoi_dir, "lakes", identifier)
                if resolve_source(cfg.aoi_dir, "lakes", identifier).exists()
                else None
            ),
            boundary_gpkg=cfg.boundary_gpkg,
            dem_path=cfg.dem_path,
            # Tuning forwarded from the config so this branch uses the same
            # values as branch zero and every other branch.
            cost_distance_tolerance=cfg.cost_distance_tolerance,
            lateral_elevation_threshold=cfg.lateral_elevation_threshold,
            max_split_distance_m=cfg.max_split_distance_m,
            slope_min=cfg.slope_min,
            lakes_buffer_dist_m=cfg.lakes_buffer_dist_m,
            mannings_n=cfg.mannings_n,
            stage_min_m=cfg.stage_min_m,
            stage_interval_m=cfg.stage_interval_m,
            stage_max_m=cfg.stage_max_m,
            min_catchment_area=cfg.min_catchment_area,
            min_stream_length=cfg.min_stream_length,
            crosswalk_max_distance_m=cfg.crosswalk_max_distance_m,
            src_slope_source=cfg.src_slope_source,
            hfab_slope_column=cfg.hfab_slope_column,
        ).run()

        # USGS gage crosswalk (optional)
        aoi_gages = cfg.aoi_dir / "usgs_subset_gages.gpkg"
        if aoi_gages.is_file():
            catchments_xwalk = (
                branch_dir
                / f"gw_catchments_reaches_filtered_addedAttributes_crosswalked_{branch_id}.gpkg"
            )
            flows = branch_dir / f"demDerived_reaches_split_filtered_{branch_id}.gpkg"
            dem_b = branch_dir / f"dem_meters_{branch_id}.tif"
            dem_adj = branch_dir / f"dem_thalwegCond_{branch_id}.tif"
            if all(p.exists() for p in (catchments_xwalk, flows, dem_b, dem_adj)):
                try:
                    run_branch_crosswalk(
                        aoi_gages_gpkg=aoi_gages,
                        branch_catchments_gpkg=catchments_xwalk,
                        branch_flows_gpkg=flows,
                        dem_path=dem_b,
                        dem_thalweg_path=dem_adj,
                        branch_id=branch_id,
                        out_dir=branch_dir,
                        target_crs=cfg.target_crs,
                    )
                except Exception as exc:
                    branch_log.warning(
                        f"USGS crosswalk skipped for branch {branch_id}: {exc}"
                    )

        # Crosswalk accuracy diagnostic (branch-zero only).
        if cfg.evaluate_crosswalk and branch_id == cfg.branch_zero_id:
            from .evaluate_crosswalk import evaluate_crosswalk as _eval_xw

            xw_flows = (
                branch_dir
                / f"demDerived_reaches_split_filtered_addedAttributes_crosswalked_{branch_id}.gpkg"
            )
            hw = cfg.headwaters_gpkg or resolve_source(
                cfg.aoi_dir, "headwaters_points", identifier
            )
            if xw_flows.exists() and hw and Path(hw).exists():
                try:
                    _eval_xw(
                        flows_gpkg=xw_flows,
                        nwm_flows_gpkg=cfg.streams_gpkg,
                        nwm_headwaters_gpkg=hw,
                        out_csv=cfg.aoi_dir / f"crosswalk_evaluation_{branch_id}.csv",
                        aoi_id=cfg.aoi_id,
                        branch_id=branch_id,
                    )
                except Exception as exc:
                    branch_log.warning(
                        f"evaluate_crosswalk skipped for branch {branch_id}: {exc}"
                    )
            else:
                branch_log.info(
                    f"evaluate_crosswalk skipped for branch {branch_id}: "
                    f"required inputs missing"
                )

        # Int16 storage downcast.
        if cfg.convert_to_int16:
            if str(cfg.aoi_id).startswith("19"):
                branch_log.info(f"convert_to_int16 skipped (Alaska AOI {cfg.aoi_id})")
            else:
                from .convert_to_int16 import (
                    CannotConvertHydroIDsToInt16,
                    convert_branch_to_int16,
                )

                try:
                    convert_branch_to_int16(branch_dir)
                except CannotConvertHydroIDsToInt16 as exc:
                    branch_log.error(
                        f"convert_to_int16 cannot run for branch {branch_id}: {exc}"
                    )
                except Exception as exc:
                    branch_log.warning(
                        f"convert_to_int16 skipped for branch {branch_id}: {exc}"
                    )

        # Per-branch deny-list cleanup is deferred until every branch in
        # the AOI finishes. process_branches() runs _cleanup_after_all
        # after the parallel loop completes.

        elapsed = time.time() - started
        branch_log.info(f"--- Branch {branch_id} ok ({elapsed:.1f}s) ---")
        return BranchResult(branch_id=branch_id, status="ok", elapsed_s=elapsed)

    except Exception as exc:
        elapsed = time.time() - started
        msg = f"{exc}\n{traceback.format_exc()}"
        status = _classify_branch_error(msg)
        # The step that blew up (CreateHAND, BranchZero, ...) already wrote the
        # traceback through log_errors; don't print it a second time.
        branch_log.error(
            f"Branch {branch_id} {status} ({elapsed:.1f}s): {exc}",
            exc_info=not already_logged(exc),
        )
        if status in ("no_flowlines", "no_crosswalk", "too_many_hydroids"):
            if cfg.keep_failed_branches:
                branch_log.warning(
                    f"Branch {branch_id} {status}: keeping dir for debugging "
                    "(keep_failed_branches=True)"
                )
            else:
                _wipe_branch_dir(branch_dir)
        return BranchResult(
            branch_id=branch_id, status=status, elapsed_s=elapsed, error=msg
        )

    finally:
        # Always detach + close the per-branch file handler so the workers
        # don't leak file descriptors across the ProcessPool.
        try:
            logging.getLogger("fimbox").removeHandler(branch_log_handler)
            branch_log_handler.close()
        except Exception:
            pass


def _classify_branch_error(msg: str) -> str:
    """Translate a branch exception's text into a status code."""
    text = msg.lower()
    if "noflowlines" in text or "no valid flowlines" in text or "no flowlines" in text:
        return "no_flowlines"
    if "nocrosswalk" in text or "no crosswalks" in text:
        return "no_crosswalk"
    if "too many hydroids" in text or "hydroid with more than 8 digits" in text:
        return "too_many_hydroids"
    return "failed"


def _wipe_branch_dir(branch_dir: Path) -> None:
    """Remove a failed branch's output directory (branches that hit 61/64/65)
    so they don't pollute later aggregation."""
    if branch_dir.is_dir():
        import shutil

        shutil.rmtree(branch_dir, ignore_errors=True)


def _write_single_branch_polygon(
    branch_polygons_gpkg,
    branch_id: str,
    branch_dir: Path,
    branch_id_attribute: str = "levpa_id",
):
    """Extract the polygon for ``branch_id`` from the AOI-wide
    branch_polygons.gpkg and write it as a single-feature gpkg inside
    branch_dir. Returns the new path, or None if the source file is
    missing or has no matching feature.

    Non-zero branches use this polygon as their clip boundary so the
    per-branch DEM is small (~MB) instead of full-AOI sized.
    """
    if branch_polygons_gpkg is None or not Path(branch_polygons_gpkg).is_file():
        return None
    try:
        import geopandas as gpd

        gdf = gpd.read_file(branch_polygons_gpkg)
    except Exception as exc:
        log.warning(f"Could not read {branch_polygons_gpkg}: {exc}")
        return None

    if branch_id_attribute not in gdf.columns:
        log.warning(
            f"branch_polygons.gpkg has no '{branch_id_attribute}' column; "
            "falling back to AOI boundary"
        )
        return None

    sub = gdf[gdf[branch_id_attribute].astype(str) == str(branch_id)]
    if sub.empty:
        return None

    out_path = branch_dir / f"branch_polygon_{branch_id}.gpkg"
    sub.to_file(out_path, driver="GPKG")
    return out_path


def _filter_by_levpa_id(
    src_gpkg,
    branch_id: str,
    branch_dir: Path,
    out_name: str,
    branch_id_attribute: str = "levpa_id",
):
    if src_gpkg is None or not Path(src_gpkg).is_file():
        return None
    try:
        import geopandas as gpd

        gdf = gpd.read_file(src_gpkg)
    except Exception as exc:
        log.warning(f"Could not read {src_gpkg}: {exc}")
        return None
    if branch_id_attribute not in gdf.columns:
        return None
    sub = gdf[gdf[branch_id_attribute].astype(str) == str(branch_id)]
    if sub.empty:
        return None
    out_path = branch_dir / out_name
    sub.to_file(out_path, driver="GPKG")
    return out_path


def _log_branch_summary(results: Sequence[BranchResult], elapsed_s: float) -> None:
    n_ok = sum(1 for r in results if r.status == "ok")
    n_fail = sum(1 for r in results if r.status == "failed")
    n_killed = sum(1 for r in results if r.status == "killed")
    n_no_flow = sum(1 for r in results if r.status == "no_flowlines")
    n_no_xw = sum(1 for r in results if r.status == "no_crosswalk")
    log.info(
        f"--- Branch summary: {n_ok} ok | {n_no_flow} no-flowlines | "
        f"{n_no_xw} no-crosswalk | {n_fail} failed | {n_killed} killed (OOM) "
        f"| total {elapsed_s:.1f}s ---"
    )
    if n_killed:
        killed_ids = [r.branch_id for r in results if r.status == "killed"]
        log.warning(
            "Killed branches (rerun individually with FIMBOX_DASK_WORKERS=1 "
            "for max RAM per worker): %s",
            ", ".join(killed_ids),
        )


# CLI
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description=(
            "Run BranchZero + CreateHAND + USGS crosswalk for every branch "
            "in an AOI. Pure branch calculation — run "
            "``python -m fimbox.preprocessing.calibrate_ratingcurve.pipeline`` separately "
            "for calibration after this finishes."
        )
    )
    parser.add_argument("--aoi-dir", required=True)
    parser.add_argument("--aoi-id", required=True)
    parser.add_argument("--branch-list", default=None)
    parser.add_argument(
        "--workers",
        type=int,
        default=None,
        help="Parallel branch workers. Omit to size to the machine; 1 for serial.",
    )
    parser.add_argument("--fema-nfhl", default=None)
    parser.add_argument("--usgs-gages", default=None)
    parser.add_argument("--ahps", default=None)
    parser.add_argument("--ras-locs", default=None)
    parser.add_argument("--target-crs", default="5070")
    parser.add_argument(
        "--evaluate-crosswalk",
        action="store_true",
        help="Write crosswalk_evaluation_<branch>.csv for branch zero only.",
    )
    parser.add_argument(
        "--convert-to-int16",
        action="store_true",
        help="Downcast gw_catchments + REM rasters to Int16 (skipped for AOI id starting with '19').",
    )
    parser.add_argument(
        "--gage-aoi-filter-column",
        default="HUC8",
        help=(
            "Column in the USGS gages gpkg that identifies AOI membership "
            "(default HUC8; use 'aoi_id' when the gpkg came from DownloadUSGSGages)."
        ),
    )
    parser.add_argument(
        "--run-branch-zero-usgs-crosswalk",
        action="store_true",
        help="Run the USGS crosswalk for branch zero after its CreateHAND finishes.",
    )
    parser.add_argument(
        "--no-delete-deny-list",
        action="store_true",
        help=(
            "Skip branch-zero deny-list cleanup. Default behaviour deletes "
            "intermediates using fimbox/config/deny_branch_zero.lst (or the "
            "file specified by --deny-branch-zero-list)."
        ),
    )
    parser.add_argument(
        "--deny-branch-zero-list",
        default=None,
        help=(
            "Path to a branch-zero deny-list. When omitted and cleanup is on, "
            "fimbox/config/deny_branch_zero.lst is used. Lines starting with "
            "'#' are comments; '{}' is substituted with the branch id."
        ),
    )
    args = parser.parse_args()

    aoi_dir = Path(args.aoi_dir)
    cfg = AOIProcessingConfig(
        aoi_dir=aoi_dir,
        aoi_id=args.aoi_id,
        branch_list_path=(
            Path(args.branch_list) if args.branch_list else (aoi_dir / "branch_ids.lst")
        ),
        n_workers=args.workers,
        fema_nfhl_gpkg=Path(args.fema_nfhl) if args.fema_nfhl else None,
        usgs_gages_gpkg=Path(args.usgs_gages) if args.usgs_gages else None,
        ahps_gpkg=Path(args.ahps) if args.ahps else None,
        ras_locs_gpkg=Path(args.ras_locs) if args.ras_locs else None,
        target_crs=args.target_crs,
        evaluate_crosswalk=args.evaluate_crosswalk,
        convert_to_int16=args.convert_to_int16,
        gage_aoi_filter_column=args.gage_aoi_filter_column,
        run_branch_zero_usgs_crosswalk=args.run_branch_zero_usgs_crosswalk,
        delete_deny_list=not args.no_delete_deny_list,
        deny_branch_zero_list=(
            Path(args.deny_branch_zero_list) if args.deny_branch_zero_list else None
        ),
    )
    process_branches(cfg)
